import mysql from "mysql2/promise";

const connection = await mysql.createConnection({
  host: process.env.RDS_HOSTNAME || "localhost",
  user: process.env.RDS_USERNAME || "root",
  password: process.env.RDS_PASSWORD || "password",
  database: process.env.RDS_DATABASE || "mm_route_service",
});

const getLocations = async (routeid) => {
  console.log("routeid->", routeid);
  const locations = await connection.query(
    "SELECT * FROM location where RouteSessionID= ?",
    routeid
  );

  return {
    locations: locations[0],
  };
};

// setTimeout(async () => {
//   console.log(
//     "getLocations->",
//     JSON.stringify(await getLocations("64bebf32d38530406ca4f254"))
//   );
// });

export const handler = getLocations;
